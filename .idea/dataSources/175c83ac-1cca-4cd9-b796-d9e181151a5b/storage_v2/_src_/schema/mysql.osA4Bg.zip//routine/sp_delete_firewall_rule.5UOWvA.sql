create
    definer = azure_superuser@localhost procedure sp_delete_firewall_rule(IN firewallName varchar(128))
BEGIN 	DECLARE ruleType INT DEFAULT 0; 	DECLARE CONTINUE HANDLER FOR NOT FOUND BEGIN END; 	SELECT rule_type into ruleType FROM `mysql`.`__firewall_rules__`  WHERE `name`=firewallName; 	IF(ruleType != 1) THEN 		DELETE FROM `mysql`.`__firewall_rules__` 		WHERE `name`=firewallName; 		SELECT ROW_COUNT(); 		FLUSH FIREWALL_RULES; 	END IF; END;

