create
    definer = azure_superuser@localhost procedure sp_set_td_alert(IN policy_id int, IN name varchar(128),
                                                                  IN enabled bit, IN params varchar(10000))
BEGIN     SET enabled = IFNULL(enabled, 0);     CALL `mysql`.`sp_td_create_tables`;     UPDATE `mysql`.`__td_alerts_configuration__` AS Alert     SET `[enabled]` = enabled,         `params` = params     WHERE Alert.policy_id = policy_id AND Alert.name = name;     INSERT IGNORE INTO `mysql`.`__td_alerts_configuration__`(`policy_id`, `name`, `[enabled]`, `params`)     VALUES (policy_id, name, enabled, params); END;

