create
    definer = azure_superuser@`127.0.0.1` function az_function_server_start_time() returns timestamp(6)
BEGIN   RETURN CURRENT_TIMESTAMP(6) - INTERVAL `mysql`.`az_function_uptime_seconds_as_bigint`() SECOND; END;

