create
    definer = azure_superuser@`127.0.0.1` function az_function_seconds_ago_based_on_uptime_as_picoseconds(minus_seconds int unsigned) returns bigint unsigned
BEGIN   RETURN `mysql`.`az_function_seconds_ago_based_on_uptime`(minus_seconds) * 1000000000000; END;

