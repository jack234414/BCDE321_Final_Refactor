create
    definer = azure_superuser@localhost procedure sp_upgrade_recommendation_schema()
BEGIN 	IF NOT EXISTS (SELECT * FROM information_schema.STATISTICS WHERE INDEX_NAME = 'idx_recommendation_exptime' AND TABLE_NAME = '__recommendation_session__' AND TABLE_SCHEMA = 'mysql') 	THEN 		ALTER TABLE `mysql`.`__recommendation_session__` ADD INDEX `idx_recommendation_exptime` (`expiration_time`); 	END IF; END;

