create
    definer = azure_superuser@localhost procedure az_update_wait_stats_procedure_status(IN procedure_kind varchar(32),
                                                                                        IN procedure_step varchar(16),
                                                                                        IN latest_attempt_time timestamp)
BEGIN   DECLARE previous_slb_val INT;   SET previous_slb_val = @@session.sql_log_bin;   SET @@session.sql_log_bin = 0;   INSERT INTO `mysql`.`__querystore_wait_stats_procedure_status__`   (     `procedure_kind`,     `procedure_step`,     `latest_attempt_time`   )   VALUES   (     procedure_kind,     procedure_step,     latest_attempt_time   )   ON DUPLICATE KEY UPDATE     `mysql`.`__querystore_wait_stats_procedure_status__`.`latest_attempt_time` = VALUES(latest_attempt_time);   SET @@session.sql_log_bin = previous_slb_val; END;

