create definer = azure_superuser@localhost view recommendation as
select `recommendation_session`.`session_id`      AS `session_id`,
       `recommendation_session`.`advisor_type`    AS `advisor_type`,
       `recommendation_session`.`create_time`     AS `create_time`,
       `recommendation_session`.`stop_time`       AS `stop_time`,
       `recommendation_session`.`expiration_time` AS `expiration_time`,
       `recommendation_session`.`session_context` AS `session_context`,
       `recommendation_session`.`state`           AS `state`,
       `recommendation`.`recommendation_id`       AS `recommendation_id`,
       `recommendation`.`recommendation_type`     AS `recommendation_type`,
       `recommendation`.`reason`                  AS `reason`,
       `recommendation`.`recommendation_context`  AS `recommendation_context`
from (`mysql`.`__recommendation_session__` `recommendation_session`
         join `mysql`.`__recommendation__` `recommendation`
              on ((`recommendation_session`.`session_id` = `recommendation`.`session_id`)));

