create
    definer = azure_superuser@localhost procedure az_purge_querystore_data(IN time_stamp timestamp)
BEGIN   DECLARE previous_slb_val INT;   SET previous_slb_val = @@session.sql_log_bin;   SET @@session.sql_log_bin = 0;     START TRANSACTION;     DELETE FROM `mysql`.`__querystore_query_metrics__` WHERE `timestamp_id` < time_stamp; 	DELETE FROM `mysql`.`__querystore_query_text__`     WHERE `query_id` NOT IN (select distinct `query_id` from `mysql`.`__querystore_query_metrics__`); 	COMMIT;   SET @@session.sql_log_bin = previous_slb_val; END;

