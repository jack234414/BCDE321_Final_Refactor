create
    definer = azure_superuser@`127.0.0.1` function az_function_performance_schema_timer_to_timestamp(pico_since_server_start bigint unsigned) returns timestamp(6)
BEGIN   RETURN `mysql`.`az_function_server_start_time`() + INTERVAL ROUND(pico_since_server_start / 1000000) MICROSECOND; END;

