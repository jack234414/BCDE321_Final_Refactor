create
    definer = azure_superuser@localhost procedure sp_get_td_emails(IN get_server_emails bit)
BEGIN     DECLARE db_mask     TINYINT DEFAULT 0x1;     DECLARE server_mask TINYINT DEFAULT 0x2;     DECLARE scope_mask TINYINT;     SET scope_mask = IF(get_server_emails = 1, server_mask, db_mask);     IF EXISTS(SELECT * FROM `information_schema`.`tables` WHERE `table_schema` = 'mysql' and `table_name` = '__email_notifications__') THEN         SELECT email FROM `mysql`.`__email_notifications__`         WHERE is_for_td IS NOT NULL AND is_for_td & scope_mask = scope_mask;     END IF; END;

