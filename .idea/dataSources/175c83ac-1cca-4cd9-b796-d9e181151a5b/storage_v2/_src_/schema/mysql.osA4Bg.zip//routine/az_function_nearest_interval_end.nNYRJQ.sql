create
    definer = azure_superuser@`127.0.0.1` function az_function_nearest_interval_end(time_stamp timestamp, interval_seconds int unsigned) returns timestamp
BEGIN   RETURN FROM_UNIXTIME(FLOOR((UNIX_TIMESTAMP(time_stamp)+interval_seconds)/interval_seconds)*interval_seconds); END;

