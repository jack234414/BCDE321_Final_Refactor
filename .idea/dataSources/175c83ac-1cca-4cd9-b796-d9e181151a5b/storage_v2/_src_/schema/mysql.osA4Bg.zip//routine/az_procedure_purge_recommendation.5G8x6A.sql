create
    definer = azure_superuser@localhost procedure az_procedure_purge_recommendation(IN time_stamp timestamp)
BEGIN   DECLARE previous_slb_val INT;   SET previous_slb_val = @@session.sql_log_bin;   SET @@session.sql_log_bin = 0;   START TRANSACTION;   DELETE `mysql`.`__recommendation__`, `mysql`.`__recommendation_session__`   FROM `mysql`.`__recommendation__`   RIGHT JOIN `mysql`.`__recommendation_session__` ON `mysql`.`__recommendation_session__`.`session_id` = `mysql`.`__recommendation__`.`session_id`   WHERE `mysql`.`__recommendation_session__`.`expiration_time` < time_stamp;   COMMIT;   SET @@session.sql_log_bin = previous_slb_val; END;

