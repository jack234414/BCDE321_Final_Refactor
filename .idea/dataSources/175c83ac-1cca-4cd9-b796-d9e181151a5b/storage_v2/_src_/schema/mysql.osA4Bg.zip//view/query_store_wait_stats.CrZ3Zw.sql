create definer = azure_superuser@localhost view query_store_wait_stats as
select `event_wait`.`interval_start`         AS `interval_start`,
       `event_wait`.`interval_end`           AS `interval_end`,
       `query_text`.`query_id`               AS `query_id`,
       `query_text`.`query_digest_id`        AS `query_digest_id`,
       `query_text`.`query_digest_text`      AS `query_digest_text`,
       `event_wait`.`wait_event_type`        AS `event_type`,
       `event_wait`.`wait_event_name`        AS `event_name`,
       `event_wait`.`wait_count_star`        AS `count_star`,
       `event_wait`.`wait_sum_timer_wait_ms` AS `sum_timer_wait_ms`
from (`mysql`.`__querystore_event_wait__` `event_wait`
         join `mysql`.`__querystore_query_text__` `query_text`
              on ((`event_wait`.`query_digest_id` = `query_text`.`query_digest_id`)));

