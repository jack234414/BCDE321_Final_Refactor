create
    definer = azure_superuser@localhost procedure sp_get_td_alerts(IN policy_id int)
BEGIN     IF EXISTS(SELECT * FROM `information_schema`.`tables` WHERE `table_schema` = 'mysql' and `table_name` = '__td_alerts_configuration__') THEN         SELECT *          FROM `mysql`.`__td_alerts_configuration__`         WHERE policy_id = policy_id;     END IF; END;

