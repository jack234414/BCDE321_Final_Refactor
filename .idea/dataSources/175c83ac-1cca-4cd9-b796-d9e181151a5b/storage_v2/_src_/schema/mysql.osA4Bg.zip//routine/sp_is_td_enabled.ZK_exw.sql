create
    definer = azure_superuser@localhost procedure sp_is_td_enabled(OUT is_td_enabled bit)
BEGIN     SET is_td_enabled = 0;     IF EXISTS(SELECT * FROM `information_schema`.`tables` WHERE `table_schema` = 'mysql' and `table_name` = '__td_policies__') THEN         IF EXISTS(SELECT * FROM `mysql`.`__td_policies__` WHERE is_server_policy = 1 AND enabled = 1) THEN             SET is_td_enabled = 1;         END IF;     END IF; END;

