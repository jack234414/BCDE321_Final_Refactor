create
    definer = azure_superuser@localhost procedure sp_upgrade_replica_information_table()
BEGIN  	IF NOT EXISTS (SELECT * FROM information_schema.COLUMNS WHERE COLUMN_NAME = 'BINARY_LOG_FILE' AND TABLE_NAME = '__az_replica_information__' AND TABLE_SCHEMA = 'mysql') 	THEN 		ALTER TABLE `mysql`.`__az_replica_information__` 		ADD COLUMN `BINARY_LOG_FILE` VARCHAR(32) AFTER `REPL_THUMBPRINT`; 	END IF; END;

