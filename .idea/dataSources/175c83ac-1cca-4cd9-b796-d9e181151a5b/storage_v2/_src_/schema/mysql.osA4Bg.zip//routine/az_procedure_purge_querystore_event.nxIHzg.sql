create
    definer = azure_superuser@localhost procedure az_procedure_purge_querystore_event(IN time_stamp timestamp)
BEGIN   DECLARE previous_slb_val INT;   SET previous_slb_val = @@session.sql_log_bin;   SET @@session.sql_log_bin = 0;   START TRANSACTION;   DELETE FROM `mysql`.`__querystore_event_wait__`     WHERE `mysql`.`__querystore_event_wait__`.`interval_end` < time_stamp;   COMMIT;   SET @@session.sql_log_bin = previous_slb_val; END;

