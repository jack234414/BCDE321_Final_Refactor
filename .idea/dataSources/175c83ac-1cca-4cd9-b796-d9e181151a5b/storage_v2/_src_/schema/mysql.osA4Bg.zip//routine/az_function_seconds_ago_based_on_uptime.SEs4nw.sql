create
    definer = azure_superuser@`127.0.0.1` function az_function_seconds_ago_based_on_uptime(minus_seconds int unsigned) returns bigint unsigned
BEGIN   DECLARE uptime_in_seconds BIGINT(20);   SET uptime_in_seconds = `mysql`.`az_function_uptime_seconds_as_bigint`();   IF uptime_in_seconds > minus_seconds THEN     SET uptime_in_seconds = uptime_in_seconds - minus_seconds;   ELSE     SET uptime_in_seconds = 0;   END IF;   RETURN uptime_in_seconds; END;

