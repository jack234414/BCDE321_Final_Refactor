create
    definer = azure_superuser@localhost procedure sp_create_email_notifications_table()
BEGIN     CREATE TABLE IF NOT EXISTS `mysql`.`__email_notifications__` (         `id` INT NOT NULL PRIMARY KEY,         `email` NVARCHAR(320) NOT NULL,         `is_for_td` TINYINT     );     ALTER TABLE `mysql`.`__email_notifications__` DROP PRIMARY KEY, MODIFY COLUMN `id` INT NOT NULL PRIMARY KEY AUTO_INCREMENT; END;

