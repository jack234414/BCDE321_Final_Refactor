create
    definer = azure_superuser@`127.0.0.1` function az_function_uptime_seconds_as_bigint() returns bigint unsigned
BEGIN   RETURN CAST((SELECT VARIABLE_VALUE FROM performance_schema.GLOBAL_STATUS WHERE VARIABLE_NAME = 'UPTIME') AS UNSIGNED); END;

