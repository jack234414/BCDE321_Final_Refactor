create definer = azure_superuser@localhost view query_store as
select `q_metrics`.`schema_name`                 AS `schema_name`,
       `q_metrics`.`query_id`                    AS `query_id`,
       `q_metrics`.`timestamp_id`                AS `timestamp_id`,
       `q_text`.`query_digest_id`                AS `query_digest_id`,
       `q_text`.`query_digest_text`              AS `query_digest_text`,
       `q_text`.`query_digest_truncated`         AS `query_digest_truncated`,
       `q_text`.`query_sample_text`              AS `query_sample_text`,
       `q_text`.`query_sample_text_truncated`    AS `query_sample_text_truncated`,
       `q_text`.`query_type`                     AS `query_type`,
       `q_metrics`.`execution_count`             AS `execution_count`,
       `q_metrics`.`warning_count`               AS `warning_count`,
       `q_metrics`.`error_count`                 AS `error_count`,
       `q_metrics`.`sum_timer_wait_ms`           AS `sum_timer_wait`,
       `q_metrics`.`avg_timer_wait_ms`           AS `avg_timer_wait`,
       `q_metrics`.`min_timer_wait_ms`           AS `min_timer_wait`,
       `q_metrics`.`max_timer_wait_ms`           AS `max_timer_wait`,
       `q_metrics`.`sum_lock_time`               AS `sum_lock_time`,
       `q_metrics`.`sum_rows_affected`           AS `sum_rows_affected`,
       `q_metrics`.`sum_rows_sent`               AS `sum_rows_sent`,
       `q_metrics`.`sum_rows_examined`           AS `sum_rows_examined`,
       `q_metrics`.`sum_select_full_join`        AS `sum_select_full_join`,
       `q_metrics`.`sum_select_scan`             AS `sum_select_scan`,
       `q_metrics`.`sum_sort_rows`               AS `sum_sort_rows`,
       `q_metrics`.`sum_no_index_used`           AS `sum_no_index_used`,
       `q_metrics`.`sum_no_good_index_used`      AS `sum_no_good_index_used`,
       `q_metrics`.`sum_created_tmp_tables`      AS `sum_created_tmp_tables`,
       `q_metrics`.`sum_created_tmp_disk_tables` AS `sum_created_tmp_disk_tables`,
       `q_text`.`first_seen`                     AS `first_seen`,
       `q_text`.`last_seen`                      AS `last_seen`
from (`mysql`.`__querystore_query_metrics__` `q_metrics`
         join `mysql`.`__querystore_query_text__` `q_text` on (((`q_metrics`.`query_id` = `q_text`.`query_id`) and
                                                                (ifnull(`q_metrics`.`schema_name`, '') =
                                                                 ifnull(`q_text`.`schema_name`, '')))));

