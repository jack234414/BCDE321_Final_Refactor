create
    definer = azure_superuser@localhost procedure sp_get_all_email_notifications()
BEGIN     IF EXISTS(SELECT * FROM `information_schema`.`tables` WHERE `table_schema` = 'mysql' AND `table_name` = '__td_email_notifications__') THEN          SELECT * FROM `mysql`.`__td_email_notifications__`;     END IF; END;

