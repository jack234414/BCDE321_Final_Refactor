create
    definer = azure_superuser@localhost procedure sp_get_td_policy(IN get_server_policy bit)
BEGIN     SET get_server_policy = IFNULL(get_server_policy, 0);     IF EXISTS(SELECT * FROM `information_schema`.`tables` WHERE `table_schema` = 'mysql' and `table_name` = '__td_policies__') THEN         SELECT *          FROM `mysql`.`__td_policies__`         WHERE is_server_policy = get_server_policy;     END IF; END;

